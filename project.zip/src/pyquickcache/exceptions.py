class CacheError(Exception):
    """Base exception for all pyquickcache errors."""
    pass


class KeyNotFound(CacheError):
    def __init__(self, key: str):
        super().__init__(f"Key not found: {key}")
        self.key = key


class KeyExpired(CacheError):
    def __init__(self, key: str):
        super().__init__(f"Key expired: {key}")
        self.key = key


class DuplicateKey(CacheError):
    def __init__(self, key: str):
        super().__init__(f"Key already exists: {key}")
        self.key = key


class InvalidTTL(CacheError):
    def __init__(self, ttl):
        super().__init__(f"Invalid TTL: {ttl}")
        self.ttl = ttl
